package com.example.myapplication;

public class ItemModel {

    private final Integer iconId;
    private final String characters;

    public ItemModel(Integer iconId, String characters) {
        this.iconId = iconId;
        this.characters = characters;
    }

    public Integer getIconId() {
        return iconId;
    }

    public String getCharacters() {
        return characters;
    }
}
