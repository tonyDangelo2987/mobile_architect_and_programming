package com.example.myapplication;

import java.util.ArrayList;

public class ArrayListModel {

    public ArrayList<ItemModel> setListData() {
        ArrayList<ItemModel> arrayList = new ArrayList<>();
        arrayList.add(new ItemModel(R.drawable.bobby,"Bobby"));
        arrayList.add(new ItemModel(R.drawable.donna,"Donna"));
        arrayList.add(new ItemModel(R.drawable.dalecooper,"Dale Cooper"));
        arrayList.add(new ItemModel(R.drawable.shelly,"Shelly"));
        arrayList.add(new ItemModel(R.drawable.laura,"Laura"));
        arrayList.add(new ItemModel(R.drawable.audrey,"Audrey"));
        arrayList.add(new ItemModel(R.drawable.james,"James"));
        arrayList.add(new ItemModel(R.drawable.harry,"Harry"));
        arrayList.add(new ItemModel(R.drawable.lucy,"Lucy"));

        return arrayList;
    }
}
