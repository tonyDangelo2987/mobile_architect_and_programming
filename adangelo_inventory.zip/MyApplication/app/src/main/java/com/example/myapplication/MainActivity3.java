package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity implements AdapterView.OnItemClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        GridView gridView = findViewById(R.id.gridView);
        GridViewAdapter gridViewAdapter = new
                GridViewAdapter(MainActivity3.this,
                new ArrayListModel().setListData());

        gridView.setAdapter(gridViewAdapter);
        gridView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ItemModel model = (ItemModel) parent.getItemAtPosition(position);
        Toast.makeText(MainActivity3.this, "Clicked by : " + model.getCharacters(),Toast.LENGTH_SHORT).show();
    }
}